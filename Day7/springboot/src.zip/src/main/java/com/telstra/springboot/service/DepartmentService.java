package com.telstra.springboot.service;

import com.telstra.springboot.entity.Department;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

public interface DepartmentService {
    public Department saveDepartment(Department department);

    public List<Department> fetchDepartmentList();

    public Department fetchDepartmentById(Long departmentID);

    public void deleteDepartmentById(Long departmentID);


    public Department updateDepartmentById(Long departmentID, Department department);
}
